The input files in1.txt and in2.txt contains the file names. To read the file properly, either 

(1) run the program in the same folder as of input files

OR

(2) copy the files file1.txt and file2.txt to the folder in which the program is running 
