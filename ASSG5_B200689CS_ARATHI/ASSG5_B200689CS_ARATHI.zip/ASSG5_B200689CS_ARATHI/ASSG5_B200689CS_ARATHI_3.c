#include<stdio.h>
#include<stdlib.h>
struct Stack
{
    int top;
    unsigned capacity;
    char* arr;
};
typedef struct Stack *stack;
int Stack_empty(stack S)
{
    if(S->top==-1)
        return -1;
    else 
        return 1;
}
int Stack_full(stack S)
{
    if(S->top==(S->capacity-1))
        return -1;
    else 
        return 1;
}
void PUSH(stack S,char k)
{
    if(Stack_full(S)==-1)
            printf("-1\n");
    else
    {
        S->top=S->top+1;
        S->arr[S->top]=k;
    }
}
void POP(stack S)
{
    if(Stack_empty(S)==-1)
            printf("-1\n");
    else
    {
        printf("%c\n",S->arr[S->top]);
        S->top--;
    }
}
void PEEK(stack S)
{
    if(Stack_empty(S)==-1)
        printf("-1\n");
    else
        printf("%c\n",S->arr[S->top]);
}
void main()
{
    int n;
    scanf("%d",&n);
    char ch,k;
    stack S=(stack)malloc(sizeof(stack));
    S->capacity =n;
    S->top=-1;
    //printf("stack capacity is %d ",S->capacity);
    S->arr=(char*)malloc(S->capacity*sizeof(char));
    while(1)
    {
        scanf(" %c", &ch);
        //printf("char is %c \n",ch);
        switch(ch)
        {
            case 'i':
                 //printf("testing at i begining\n");
                 scanf(" %c",&k);
                 //printf("cnew is %c\n",k);
                 PUSH(S,k);
                 //printf("testing at f ending\n");
                 break;

            case 'd':
                 //printf("testing at t begining\n");
                 POP(S);
                 //printf("testing at t ending\n");
                 break;

             case 'p':
                // printf("testing at t begining\n");
                 PEEK(S);
                 //printf("testing at t ending\n");
                 break;
            case 't':
                 exit(0);
                 break;
        }
    }
}
