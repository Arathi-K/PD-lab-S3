#include<stdio.h>
#include<stdlib.h>
#include<string.h>
struct Queue
{
    int head;
    int tail;
    char **arr;
};
typedef struct Queue *queue;
int mAx_size;
int QUEUE_FULL(queue Q)
{
    if((Q->tail==mAx_size-1 && Q->head ==0 )|| Q->tail==Q->head-1)
        return -1;
    else 
        return 1;
}
int QUEUE_EMPTY(queue Q)
{
    if(Q->head==Q->tail)
        return -1;
    else 
        return 1;
}
void ENQUEUE(queue Q,char k[21])
{
    if(QUEUE_FULL(Q)==-1)
            printf("-1\n");
    else
        {
             strcpy(Q->arr[Q->tail],k);
                if(Q->tail==mAx_size-1) 
                      Q->tail=0;
                else
                     Q->tail++;
        }
}
void DEQUEUE(queue Q)
{
    if(QUEUE_EMPTY(Q)==-1)
            printf("-1\n");
    else
        {
            printf("%s\n",Q->arr[Q->head]);
            if(Q->head==mAx_size-1)
                Q->head=0;
            else
                Q->head=Q->head+1;
        }
}
void main()
{
    char ch;
    char s[21];
    queue Q=(queue)malloc(sizeof(queue));
    Q->head=0;
    Q->tail=0;
    scanf("%d",&mAx_size);
    //printf("stack capacity is %d ",S->capacity);
    Q->arr=(char**)malloc(mAx_size*sizeof(char *));
    for(int i=0;i<mAx_size;i++)
    {
        Q->arr[i]=(char*)malloc(21*sizeof(char));
    }
   //Q->arr[mAx_size][];
    while(1)
    {
        scanf(" %c", &ch);
        //printf("char is %c \n",ch);
        switch(ch)
        {
            case 'i':
                 //printf("testing at i begining\n");
                 scanf(" %s",s);
                 //printf("cnew is %c\n",k);
                 ENQUEUE(Q,s);
                 //printf("testing at f ending\n");
                 break;

            case 'd':
                 //printf("testing at t begining\n");
                 DEQUEUE(Q);
                 //printf("testing at t ending\n");
                 break;

             case 'f':
                // printf("testing at t begining\n");
                 printf("%d\n",QUEUE_FULL(Q));
                 //printf("testing at t ending\n");
                 break;
            case 'e':
                // printf("testing at t begining\n");
                 printf("%d\n",QUEUE_EMPTY(Q));
                 //printf("testing at t ending\n");
                 break;
            case 't':
                 exit(0);
                 break;
        }
    }
}

