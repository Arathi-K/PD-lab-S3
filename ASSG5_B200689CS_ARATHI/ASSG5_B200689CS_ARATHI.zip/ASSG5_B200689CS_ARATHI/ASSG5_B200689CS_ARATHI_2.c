#include<stdio.h>
#include<stdlib.h>
struct node
{
    int key;
    struct node *next; 
    struct node *prev;
};
typedef struct node *node;
struct LL
{
    node head; 
};
typedef struct LL *LL;
node CREATE_NODE(int x)
{   
    node temp;
    temp=(node)malloc(sizeof(struct node));
    temp->key=x;
    temp->next=NULL;
    temp->prev =NULL;
    //printf("hhi..node created\n");
    return temp;
}
node LIST_SEARCH(LL L, int k)
{
if(L->head==NULL)
		return NULL;
node nowat=L->head;
while(nowat!=NULL)
{
	if(nowat->key==k)
		return nowat;
	nowat=nowat->next;
}
return NULL;
}
void LIST_INSERT_FRONT(LL L,node x)
{  
    node nowat= L->head;
   x->next =nowat;
   if ( L->head != NULL)
        nowat->prev=x;
   L->head = x;
   x->prev = NULL;
}
void LIST_INSERT_TAIL(LL L,node x)
{  //printf("welcome to LIST_INSERT_TAIL");
    node nowat= L->head;
    if(L->head!=NULL)
    {  
        while(nowat->next!=NULL)
            nowat=nowat->next;
        nowat->next=x;
        x->prev=nowat;
        x->next=NULL;
    }
    else 
        L->head=x;
}
void LIST_INSERT_AFTER(LL L,node x,int y)
{  
   // printf("hii");
    node nowat=LIST_SEARCH(L,y);
    x->next= nowat->next;
    x->prev=nowat;
    nowat->next->prev =x;
    nowat->next=x;
}
void LIST_INSERT_BEFORE(LL L,node x,int y)
{  
    node nowat=LIST_SEARCH(L,y);
    x->next= nowat;
    x->prev=nowat->prev;
    nowat->prev->next=x;
    nowat->prev=x;
    
}
void LIST_DELETE(LL L,int ch)
{  
node nowat=LIST_SEARCH(L,ch);
   // printf("...%d",nowat->key);
    if(nowat==NULL)//empty list or not present
    {
            printf("Not Found\n");
    } 
    else if(nowat==L->head)
    {   
        if(nowat->next == NULL)
        {
            L->head=NULL;
            printf("NULL\n");
            free(nowat);
            
        }
        else
        {
           /* printf("%d\n",nowat->next->key);
            L->head=nowat->next;
            nowat->next->prev=NULL;*/
            L->head=L->head->next;
            printf("%d ",L->head->key);
            L->head->prev=NULL;
            free(nowat);
        }
    }
    else
    {
         if(nowat->next == NULL)
        {
            nowat->prev->next=NULL;
            printf("NULL\n");
            free(nowat);  
        }
        else 
        {
        printf("%d\n",nowat->next->key);
        nowat->prev->next=nowat->next;
        nowat->next->prev=nowat->prev;
        nowat->prev=NULL;
        nowat->next=NULL;
        free(nowat);
       }
    }
}



void LIST_DELETE_FIRST(LL L)
{
    node nowat;
    if(L->head==NULL)
		 printf("Not Found\n");
	
	else
    {
        nowat=L->head;
        printf("%d\n",L->head->key);
        L->head=L->head->next;
        if(L->head!=NULL)
            L->head->prev=NULL;
        free(nowat);
    }
}
void LIST_DELETE_LAST(LL L)
{
    node nowat=L->head;
    if(nowat==NULL)
        printf("Not Found\n");
    else
    {
        while(nowat->next!=NULL)
             nowat=nowat->next;
        printf("%d\n",nowat->key);
        if(nowat->prev!=NULL)
             nowat->prev->next=NULL;
        else
            L->head=NULL;
        nowat=NULL;
    }
    free(nowat);
}
void PRINT_REVERSE(LL L,int ch)
{
    node nowat=LIST_SEARCH(L,ch);
    if(nowat==NULL)
       { 
           printf("Not Found\n");
             return;
       }
    else
    {
        do
        {
            printf("%d ",nowat->key);
            nowat=nowat->prev;
        }while(nowat!=NULL);
        printf("\n");
    }
}
void main()
{
    char ch;
    int k,y;
    node x=NULL;
    LL L;
    L=(LL)malloc(sizeof(LL));
    //L->head=NULL;
    
    
    while(1)
    {
        scanf(" %c", &ch);
     //   printf("char is %c \n",ch);
        switch(ch)
        {
            case 'f':
                 //printf("testing at f begining\n");
                 scanf(" %d",&k);
                 //printf("cnew is %d\n",k);
                 x=CREATE_NODE(k);
                 
                 LIST_INSERT_FRONT(L,x);
                 //printf("testing at f ending\n");
                 break;

            case 't':
                // printf("testing at t begining\n");
                 scanf(" %d",&k);
                 //printf("cnew is %d\n",k);
                 x=CREATE_NODE(k);
                 //printf("x created");
                 LIST_INSERT_TAIL(L,x);
                // printf("testing at t ending\n");
                 break;

             case 'a':
                 //printf("testing at a begining\n");
                 scanf(" %d %d",&k,&y);
                 x=CREATE_NODE(k);
                // printf("ur inputs are %d %d\n",k,y);
                 LIST_INSERT_AFTER(L,x,y);//x inserted after y
                 //printf("testing at a ending\n");
                 break;

            case 'b':
                // printf("testing at b begining\n");
                 scanf(" %d %d",&k,&y);
                // printf("ur inputs are %d %d\n",k,y);
                 x=CREATE_NODE(k);
                 LIST_INSERT_BEFORE(L,x,y);//x inserted before y
                // printf("testing at b ending\n");
                 break;
            case 'd':
                // printf("testing at d begining\n");
                 scanf(" %d",&k);
                 //printf("c is %d\n",k);
                 LIST_DELETE(L,k);
                 //printf("testing at d ending\n");
                 break;
               
            case 'i': LIST_DELETE_FIRST(L);break;//done

            case 'l': LIST_DELETE_LAST(L);break;//done

            case 'r': 
                scanf(" %d",&k);
                PRINT_REVERSE(L,k);break;//done

            case 'e': exit(0);break;
        }
    }
}
